import { Link } from "react-router-dom";
import React, { useState, useEffect } from "react";


export default function Main({

}) {
    useEffect(function () {

    }, []);

   

    return (
        <div className="mainContainer">
           YOLO
        </div>
    );
}
